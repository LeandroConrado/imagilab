<?php

namespace App\Filament\Resources\SalesReportResource\Pages;

use App\Filament\Pages\SalesReportResource;
use App\Models\Category;
use App\Models\OrderItem;
use Filament\Actions;
use Filament\Forms;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Resources\Pages\Page;
use Filament\Tables;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Support\Carbon;

class CategorySalesReport extends Page implements HasTable, HasForms
{
    use InteractsWithTable;
    use InteractsWithForms;

    protected static string $resource = SalesReportResource::class;

    protected static string $view = 'filament.pages.reports.category-sales-report';

    public $dateFrom;
    public $dateTo;

    public function mount(): void
    {
        $this->dateFrom = now()->startOfMonth()->format('Y-m-d');
        $this->dateTo = now()->format('Y-m-d');
    }

    public function table(Table $table): Table
    {
        return $table
            ->query($this->getTableQuery())
            ->columns([
                Tables\Columns\ImageColumn::make('category.image')
                    ->label('Imagem')
                    ->circular()
                    ->defaultImageUrl('/images/no-category.png'),

                Tables\Columns\TextColumn::make('category.name')
                    ->label('Categoria')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),

                Tables\Columns\TextColumn::make('category.description')
                    ->label('Descrição')
                    ->limit(30)
                    ->toggleable(),

                Tables\Columns\TextColumn::make('products_count')
                    ->label('Produtos')
                    ->numeric()
                    ->alignCenter()
                    ->badge()
                    ->color('info'),

                Tables\Columns\TextColumn::make('total_quantity')
                    ->label('Unidades Vendidas')
                    ->numeric()
                    ->sortable()
                    ->alignCenter()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                            ->label('Total Geral')
                    ]),

                Tables\Columns\TextColumn::make('total_sales')
                    ->label('Receita Total')
                    ->money('BRL')
                    ->sortable()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                            ->money('BRL')
                            ->label('Total Geral')
                    ]),

                Tables\Columns\TextColumn::make('average_price')
                    ->label('Preço Médio')
                    ->money('BRL')
                    ->sortable(),

                Tables\Columns\TextColumn::make('orders_count')
                    ->label('Pedidos')
                    ->numeric()
                    ->alignCenter()
                    ->badge()
                    ->color('success'),

                Tables\Columns\TextColumn::make('market_share')
                    ->label('% do Total')
                    ->getStateUsing(function ($record) {
                        $totalSales = $this->getTotalSales();
                        if ($totalSales > 0) {
                            $percentage = ($record->total_sales / $totalSales) * 100;
                            return number_format($percentage, 1) . '%';
                        }
                        return '0%';
                    })
                    ->badge()
                    ->color(function ($record) {
                        $totalSales = $this->getTotalSales();
                        if ($totalSales > 0) {
                            $percentage = ($record->total_sales / $totalSales) * 100;
                            if ($percentage >= 20) return 'success';
                            if ($percentage >= 10) return 'warning';
                            return 'gray';
                        }
                        return 'gray';
                    }),
            ])
            ->filters([
                Tables\Filters\Filter::make('period')
                    ->form([
                        Forms\Components\DatePicker::make('date_from')
                            ->label('Data Inicial')
                            ->default(now()->startOfMonth()),
                        Forms\Components\DatePicker::make('date_to')
                            ->label('Data Final')
                            ->default(now()),
                    ])
                    ->query(function ($query, array $data) {
                        return $query
                            ->when($data['date_from'], function ($q, $date) {
                                $q->whereHas('orderItems.order', fn ($orderQuery) =>
                                $orderQuery->where('created_at', '>=', $date)
                                );
                            })
                            ->when($data['date_to'], function ($q, $date) {
                                $q->whereHas('orderItems.order', fn ($orderQuery) =>
                                $orderQuery->where('created_at', '<=', $date)
                                );
                            });
                    }),

                Tables\Filters\SelectFilter::make('min_sales')
                    ->label('Vendas Mínimas')
                    ->options([
                        '1000' => 'R$ 1.000 ou mais',
                        '5000' => 'R$ 5.000 ou mais',
                        '10000' => 'R$ 10.000 ou mais',
                        '50000' => 'R$ 50.000 ou mais',
                    ])
                    ->query(function ($query, $state) {
                        if ($state['value']) {
                            return $query->having('total_sales', '>=', $state['value']);
                        }
                        return $query;
                    }),

                Tables\Filters\TernaryFilter::make('is_active')
                    ->label('Categoria Ativa')
                    ->relationship('category', 'is_active'),
            ])
            ->actions([
                Tables\Actions\Action::make('view_details')
                    ->label('Detalhes')
                    ->icon('heroicon-o-eye')
                    ->color('info')
                    ->modalHeading(fn ($record) => 'Detalhes da Categoria: ' . $record->category->name)
                    ->modalContent(fn ($record) => $this->getCategoryDetailsView($record))
                    ->modalWidth('5xl'),

                Tables\Actions\Action::make('view_products')
                    ->label('Ver Produtos')
                    ->icon('heroicon-o-cube')
                    ->color('primary')
                    ->url(function ($record) {
                        return '/admin/products?tableFilters[category][value]=' . $record->category_id;
                    })
                    ->openUrlInNewTab(),
            ])
            ->defaultSort('total_sales', 'desc')
            ->paginated([10, 25, 50]);
    }

    protected function getTableQuery()
    {
        $dateFrom = $this->dateFrom ? Carbon::parse($this->dateFrom) : now()->startOfMonth();
        $dateTo = $this->dateTo ? Carbon::parse($this->dateTo) : now();

        return Category::whereHas('products.orderItems.order', function ($query) use ($dateFrom, $dateTo) {
            $query->whereBetween('created_at', [$dateFrom, $dateTo]);
        })
            ->withCount(['products' => function ($query) {
                $query->where('status', 'active');
            }])
            ->addSelect([
                'total_quantity' => OrderItem::selectRaw('SUM(order_items.quantity)')
                    ->join('products', 'order_items.product_id', '=', 'products.id')
                    ->join('orders', 'order_items.order_id', '=', 'orders.id')
                    ->whereColumn('products.category_id', 'categories.id')
                    ->whereBetween('orders.created_at', [$dateFrom, $dateTo]),

                'total_sales' => OrderItem::selectRaw('SUM(order_items.total)')
                    ->join('products', 'order_items.product_id', '=', 'products.id')
                    ->join('orders', 'order_items.order_id', '=', 'orders.id')
                    ->whereColumn('products.category_id', 'categories.id')
                    ->whereBetween('orders.created_at', [$dateFrom, $dateTo]),

                'average_price' => OrderItem::selectRaw('AVG(order_items.price)')
                    ->join('products', 'order_items.product_id', '=', 'products.id')
                    ->join('orders', 'order_items.order_id', '=', 'orders.id')
                    ->whereColumn('products.category_id', 'categories.id')
                    ->whereBetween('orders.created_at', [$dateFrom, $dateTo]),

                'orders_count' => OrderItem::selectRaw('COUNT(DISTINCT order_items.order_id)')
                    ->join('products', 'order_items.product_id', '=', 'products.id')
                    ->join('orders', 'order_items.order_id', '=', 'orders.id')
                    ->whereColumn('products.category_id', 'categories.id')
                    ->whereBetween('orders.created_at', [$dateFrom, $dateTo]),
            ])
            ->having('total_sales', '>', 0);
    }

    protected function getTotalSales()
    {
        static $totalSales = null;

        if ($totalSales === null) {
            $dateFrom = $this->dateFrom ? Carbon::parse($this->dateFrom) : now()->startOfMonth();
            $dateTo = $this->dateTo ? Carbon::parse($this->dateTo) : now();

            $totalSales = OrderItem::whereHas('order', function ($query) use ($dateFrom, $dateTo) {
                $query->whereBetween('created_at', [$dateFrom, $dateTo]);
            })->sum('total');
        }

        return $totalSales;
    }

    protected function getCategoryDetailsView($record)
    {
        $dateFrom = $this->dateFrom ? Carbon::parse($this->dateFrom) : now()->startOfMonth();
        $dateTo = $this->dateTo ? Carbon::parse($this->dateTo) : now();

        // Top produtos da categoria
        $topProducts = OrderItem::whereHas('order', function ($query) use ($dateFrom, $dateTo) {
            $query->whereBetween('created_at', [$dateFrom, $dateTo]);
        })
            ->whereHas('product', function ($query) use ($record) {
                $query->where('category_id', $record->category_id);
            })
            ->selectRaw('
            product_id,
            SUM(quantity) as total_quantity,
            SUM(total) as total_sales,
            AVG(price) as average_price
        ')
            ->with('product')
            ->groupBy('product_id')
            ->orderByDesc('total_sales')
            ->limit(10)
            ->get();

        // Vendas por mês
        $monthlySales = OrderItem::whereHas('order', function ($query) use ($dateFrom, $dateTo) {
            $query->whereBetween('created_at', [$dateFrom, $dateTo]);
        })
            ->whereHas('product', function ($query) use ($record) {
                $query->where('category_id', $record->category_id);
            })
            ->selectRaw('
            YEAR(orders.created_at) as year,
            MONTH(orders.created_at) as month,
            SUM(order_items.quantity) as quantity,
            SUM(order_items.total) as sales
        ')
            ->join('orders', 'order_items.order_id', '=', 'orders.id')
            ->groupByRaw('YEAR(orders.created_at), MONTH(orders.created_at)')
            ->orderByRaw('YEAR(orders.created_at), MONTH(orders.created_at)')
            ->get();

        return view('filament.modals.category-sales-details', [
            'category' => $record->category,
            'stats' => [
                'total_quantity' => $record->total_quantity,
                'total_sales' => $record->total_sales,
                'average_price' => $record->average_price,
                'orders_count' => $record->orders_count,
                'products_count' => $record->products_count,
            ],
            'top_products' => $topProducts,
            'monthly_sales' => $monthlySales,
        ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('export_excel')
                ->label('📊 Exportar Excel')
                ->icon('heroicon-o-table-cells')
                ->color('success')
                ->action(fn () => $this->exportExcel()),

            Actions\Action::make('back')
                ->label('← Voltar')
                ->url(fn () => static::getResource()::getUrl('index'))
                ->color('gray'),
        ];
    }

    public function exportExcel(): void
    {
        $this->dispatch('notify', 'Exportação em desenvolvimento...');
    }

    public function getTitle(): string
    {
        return 'Relatório de Vendas por Categoria';
    }
}
